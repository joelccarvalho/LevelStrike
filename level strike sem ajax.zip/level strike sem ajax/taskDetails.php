<?php
include "dbconfig.php";

$sql_query="select titulo, descricao, dataLimite from tarefas";
$result_set=mysqli_query($link, $sql_query);
?>
<div class="container taskDetails_container">
  <p class="taskDetails_title"></p>
  <div class="panel-heading noWhite"></div><br>
  <p class="taskDetails_disc"></p><br>
<div class="panel-heading noWhite"></div>
<br><br>
<div class="taskDetails_date">
  <p class="list-group-item-text data_limite_task"><span class="glyphicon glyphicon-time"></span></p>
</div>
<?
while($row = mysqli_fetch_array($result_set)){
  ?>
  <div class="container taskDetails_container">
    <p class="taskDetails_title"><?=$row['titulo']?></p>
    <div class="panel-heading noWhite"></div><br>
    <p class="taskDetails_disc"><?=$row['descricao']?></p><br>
  <div class="panel-heading noWhite"></div>
  <br><br>
  <div class="taskDetails_date">
    <p class="list-group-item-text data_limite_task"><span class="glyphicon glyphicon-time"><?=$row['dataLimite']?></span></p>
  </div>
  <hr>
  <?
}
?>
