<?php
include "dbconfig.php";

$sql_query="select titulo, dataLimite, pontos from tarefas";
$result_set=mysqli_query($link, $sql_query);
?>
<a class="list-group-item cor_fundo_app">
  <h4 class="list-group-item-heading"></h4>
  <p class="list-group-item-text"><span class="glyphicon glyphicon-time"></span></p>
  <p class="list-group-item-text"></p>
</a>
<?
while($row = mysqli_fetch_array($result_set)){
  ?>
  <a class="list-group-item cor_fundo_app">
    <h4 class="list-group-item-heading"><?=$row['titulo']?></h4>
    <p class="list-group-item-text"><span class="glyphicon glyphicon-time"><?=$row['dataLimite']?></span></p>
    <p class="list-group-item-text"><?=$row['pontos']?> points</p>
  </a>
  <hr>
  <?
}
?>
