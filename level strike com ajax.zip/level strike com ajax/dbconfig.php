<?php
  header("Access-Control-Allow-Origin: *");
  $host = "localhost";
  $user = "root";
  $password = "mysql";
  $datbase = "LevelStrike";
  $link = mysqli_connect($host, $user, $password);
  mysqli_select_db($link, $datbase);
 ?>
